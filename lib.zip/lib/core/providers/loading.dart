import 'package:flutter/material.dart';

class LoadingProvider with ChangeNotifier {
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  String? _errorMessage;
  String? get errorMessage => _errorMessage;

  void setLoading(bool value, {String? errorMessage}) {
    _isLoading = value;
    _errorMessage = errorMessage;
    notifyListeners();
  }
}