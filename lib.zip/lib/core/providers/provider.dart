import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AuthProvider with ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  User? _user;
  String _errorMessage = '';

  User? get user => _user;
  String get errorMessage => _errorMessage;

  // Giriş yapma fonksiyonu
  Future<void> signIn(String email, String password, BuildContext context) async {
    try {
      // Firebase Authentication ile giriş yapma
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      _user = _auth.currentUser;

      _errorMessage = '';
      notifyListeners();

      Navigator.pushReplacementNamed(context, '/home');
    } catch (e) {
      _errorMessage = 'Giriş yaparken bir hata oluştu: $e';
      notifyListeners();
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
    _user = null;
    _errorMessage = '';
    notifyListeners();
  }
}